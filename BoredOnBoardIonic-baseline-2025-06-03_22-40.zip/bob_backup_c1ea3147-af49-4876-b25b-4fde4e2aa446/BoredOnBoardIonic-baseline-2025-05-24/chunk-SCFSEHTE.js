import{a,b}from"./chunk-Z4V4M3ZT.js";import"./chunk-FQ65QLOX.js";export{a as GESTURE_CONTROLLER,b as createGesture};
