import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-QLNGCGMM.js";
import "./chunk-72VSVBTI.js";
import "./chunk-R3LVCYXH.js";
import "./chunk-UQIXM5CJ.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
//# sourceMappingURL=hardware-back-button-2UIQYNJX.js.map
