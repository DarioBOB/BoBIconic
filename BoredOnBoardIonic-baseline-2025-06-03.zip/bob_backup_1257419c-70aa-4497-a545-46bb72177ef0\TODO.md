# TODO - Page Mes Voyages

- [ ] Diagnostiquer et corriger la non-réactivité du pipe translate avec paramètres pour le titre dynamique des vols
- [ ] Activer la persistance offline Firestore (mode avion)
- [ ] Ajouter la gestion multilingue pour d'autres types de voyages (train, hôtel, etc.)
- [ ] Ajouter des tests unitaires et e2e
- [ ] Améliorer l'UX (animations, transitions, effet waw)
- [ ] Ajouter une gestion d'erreur utilisateur friendly si Firestore est inaccessible
- [ ] Ajouter la possibilité de modifier/supprimer un voyage
- [ ] Ajouter la synchronisation manuelle en mode offline 