﻿# backup_baseline.ps1
# Script de backup baseline pour PowerShell
# CONSEIL : Enregistrez ce fichier en UTF-8 (sans BOM) pour éviter les problèmes d'encodage.
# Ce script utilise la branche 'main' car c'est la branche par défaut sur GitLab pour ce projet.
# 1. Reinitialise le depot git local et force le push sur GitLab (ecrase tout l'historique)
# 2. Cree une archive zip de la baseline (hors node_modules, dist, .git, etc.)
# Usage : .\backup_baseline.ps1

$ErrorActionPreference = 'Stop'

# Force l'encodage UTF-8 pour l'affichage correct
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$REMOTE_URL = "https://gitlab.com/DarioMangano/bob_backend_prod_perso.git"
$BACKUP_DIR = "../backups"
$DATE = Get-Date -Format 'yyyy-MM-dd'
$LOG_FILE = "backup_baseline.log"
$ENABLE_LOG = $false  # Passe a $true pour activer le log
$ENABLE_GIT_PUSH = $false  # Passe a $true pour activer le git push --force

# Cree le dossier backup AVANT de changer de dossier
if (!(Test-Path $BACKUP_DIR)) { New-Item -ItemType Directory -Path $BACKUP_DIR | Out-Null }
$BACKUP_DIR_ABS = Resolve-Path $BACKUP_DIR
$ARCHIVE_NAME = Join-Path $BACKUP_DIR_ABS "BoredOnBoardIonic-baseline-$DATE.zip"

if ($ENABLE_LOG) {
  Start-Transcript -Path $LOG_FILE -Force
}

Write-Host "---------------------------------------------"
Write-Host "SCRIPT DE BACKUP BASELINE (PowerShell)"
Write-Host "---------------------------------------------"
Write-Host "Remote GitLab : $REMOTE_URL"
Write-Host "Archive       : $ARCHIVE_NAME"
Write-Host "Log           : $LOG_FILE"
Write-Host

$confirm = Read-Host "ATTENTION : Ce script va ECRASER l'historique GitLab et creer une archive zip. Continuer ? (y/N) "
if ($confirm -ne 'y' -and $confirm -ne 'Y') {
    Write-Host "Abandon."
    if ($ENABLE_LOG) { Stop-Transcript }
    exit 1
}

Write-Host
Write-Host "[1] Reinitialisation du depot git local..."
Remove-Item -Recurse -Force .git -ErrorAction SilentlyContinue
& git init
Write-Host "   [OK] Depot git initialise."
& git add .
Write-Host "   [OK] Fichiers ajoutes."
& git commit -m "Baseline clean du projet - $DATE"
Write-Host "   [OK] Commit baseline effectue."
try { & git remote remove origin } catch {}
& git remote add origin $REMOTE_URL
& git branch -M main
Write-Host "   [OK] Remote et branche 'main' configures."
if ($ENABLE_GIT_PUSH) {
  Write-Host "   [INFO] Push en cours (cela peut prendre du temps)..."
  try {
    & git push --force origin main
    Write-Host "[OK] Depot GitLab mis a jour avec la baseline (branche main)."
  } catch {
    Write-Host "[WARN] Erreur lors du git push --force (branche protegee ?). Le backup zip sera quand meme cree."
  }
} else {
  Write-Host "[INFO] Push GitLab desactive, seul le backup zip sera cree."
}

Write-Host
Write-Host "[2] Creation de l'archive zip..."
# Sauvegarde le chemin absolu du projet avant de changer de dossier
$projectRoot = $PWD.Path
Set-Location ..
if (Test-Path $ARCHIVE_NAME) { Remove-Item $ARCHIVE_NAME }

# Creation d'un dossier temporaire pour le backup
$tempDir = Join-Path $env:TEMP ("bob_backup_" + [System.Guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $tempDir | Out-Null
Copy-Item "$projectRoot\*" $tempDir -Recurse -Force

# Exclure node_modules, dist, .git, *.zip, backup_baseline.log du dossier temporaire
$excludes = @("node_modules", "dist", ".git", "*.zip", "backup_baseline.log")
foreach ($exclude in $excludes) {
    Get-ChildItem -Path $tempDir -Recurse -Force -Filter $exclude | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

Compress-Archive -Path $tempDir -DestinationPath $ARCHIVE_NAME -CompressionLevel Optimal -Force
Remove-Item -Recurse -Force $tempDir
Write-Host "[OK] Archive creee : $ARCHIVE_NAME"
Set-Location $projectRoot

Write-Host
Write-Host "---------------------------------------------"
Write-Host "[OK] Backup baseline termine avec succes."
Write-Host "---------------------------------------------"

if ($ENABLE_LOG) {
  Stop-Transcript
  Write-Host "(Voir le log detaille dans $LOG_FILE)"
} 