// node_modules/@ionic/core/components/index6.js
var win = typeof window !== "undefined" ? window : void 0;
var doc = typeof document !== "undefined" ? document : void 0;

export {
  win,
  doc
};
/*! Bundled license information:

@ionic/core/components/index6.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
//# sourceMappingURL=chunk-CJ5MJUPJ.js.map
