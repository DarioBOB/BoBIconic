import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-6HCD6MJG.js";
import "./chunk-ADG6RUAB.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
