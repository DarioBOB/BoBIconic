// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBQ876_Ci6AWLBV5-nmkqLDKnCI3929v0E",
    authDomain: "bob-app-9cbfe.firebaseapp.com",
    projectId: "bob-app-9cbfe",
    storageBucket: "bob-app-9cbfe.appspot.com", // ⚠️ Corrige bien ici : .appspot.com et non .firebasestorage.app
    messagingSenderId: "163592997424",
    appId: "1:163592997424:web:ece12127e2e3f07a66bbf5",
    measurementId: "G-EMZ3P925JF"
  },
  zohoPassword: 'HzCXsEafd6PK',
  apiUrl: 'your-api-url',
  flightRadar24ApiKey: 'your-fr24-api-key',
  openaiApiKey: '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'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
