# Plan de tests fonctionnels — Administrateur

## 1. Gestion des utilisateurs
- Visualiser la liste des utilisateurs
- Désactiver/réactiver un compte
- Réinitialiser le mot de passe d’un utilisateur

## 2. Logs et audit
- Accès à l’historique des connexions
- Visualisation des actions critiques

## 3. Sécurité
- Accès restreint aux fonctions admin
- Déconnexion forcée d’un utilisateur

## 4. Multilingue
- Interface admin traduite (FR/EN)

---
À enrichir à chaque ajout de fonction admin ou retour QA. 