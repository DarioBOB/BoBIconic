import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-SNNZNKXU.js";
import "./chunk-UQIXM5CJ.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
//# sourceMappingURL=index3-ZRO5ECFO.js.map
