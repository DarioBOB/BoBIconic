import {
  addIcons,
  setAssetPath
} from "./chunk-YGPX7WIP.js";
import "./chunk-UQIXM5CJ.js";
export {
  addIcons,
  setAssetPath
};
//# sourceMappingURL=ionicons.js.map
