function r(t){return!(t.length<8||!/[A-Z]/.test(t)||!/[a-z]/.test(t)||!/[0-9]/.test(t)||!/[!@#$%^&*(),.?":{}|<>]/.test(t))}function f(t,e){return t===e}export{r as a,f as b};
